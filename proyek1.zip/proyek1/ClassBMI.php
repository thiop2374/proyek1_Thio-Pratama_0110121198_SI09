<?php
  class bmiPasien
  {
    public $nama,
      $berat,
      $tinggi,
      $umur,
      $jenisKelamin;

    public function hasilBMI()
    {
      return "<b>Nama : $this->nama   <br><br>
              Berat Badan : $this->berat <br><br>                  
              Tinggi Badan : $this->tinggi <br><br>
              Umur : $this->umur <br><br>
              Jenis Kelamin : $this->jenisKelamin</b>";
    }
    public function statusBMI($BMI)
    {
      if ($BMI < 18.5) {
        return "<td>Kekurangan Berat Badan</td>";
      } else if ($BMI >= 18.5 && $BMI <= 24.9) {
        return "<td>Normal (ideal)</td>";
      } else if ($BMI >= 25.0 && $BMI <= 29.9) {
        return "<td>Kelebihan Berat Badan</td>";
      } else {
        return "<td>Kegemukan (Obesitas)</td>";
      }
    }
  }
  if (isset($_GET["nama__lengkap"])) {
    $bmi = new bmiPasien;
    $bmi->nama = $_GET["nama__lengkap"];
    $bmi->berat = $_GET["berat__"];
    $bmi->tinggi = $_GET["tinggi__"];
    $bmi->umur = $_GET["umur__"];
    $bmi->jenisKelamin = $_GET["jenis__kelamin"];
  }
  $pasien1 = ['nama' => 'Rosalia Naurah', 'kelamin' => 'Perempuan', 'umur' => 18, 'berat' => 46.2, 'tinggi' => 155];
  $pasien2 = ['nama' => 'Rara Ulan', 'kelamin' => 'Perempuan', 'umur' => 20, 'berat' => 42.8, 'tinggi' => 158];
  $pasien3 = ['nama' => 'Glagah Putih', 'kelamin' => 'Laki-laki', 'umur' => 22, 'berat' => 90.3, 'tinggi' => 154];
  $pasien4 = ['nama' => $bmi->nama, 'kelamin' => $bmi->jenisKelamin, 'umur' => $bmi->umur, 'berat' => $bmi->berat, 'tinggi' => $bmi->tinggi];

  $ar_pasien = [$pasien1, $pasien2, $pasien3, $pasien4];
  ?>