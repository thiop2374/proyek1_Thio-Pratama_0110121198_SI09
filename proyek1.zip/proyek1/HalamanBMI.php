<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
  <title>BMI | PASIEN</title>
</head>

<body>
  <nav class="navbar navbar-dark bg-dark">
    <div class="container-fluid">
      <span class="navbar-brand mb-0 px-4 h1">KALKULATOR BMI PASIEN</span>
    </div>
  </nav>
  <div class="container">
    <h2 class="text-center mb-5">Form Pasien</h2>
    <form action="HalamanBMI.php" method="GET">
      <div class="form-group row">
        <label for="nama" class="col-4 col-form-label">Nama Lengkap</label>
        <div class="col-8">
          <input id="nama" name="nama__lengkap" type="text" class="form-control">
        </div>
      </div>
      <div class="form-group row">
        <label for="berat" class="col-4 col-form-label">Berat</label>
        <div class="col-8">
          <input id="berat" name="berat__" type="text" class="form-control">
        </div>
      </div>
      <div class="form-group row">
        <label for="tinggi" class="col-4 col-form-label">Tinggi</label>
        <div class="col-8">
          <input id="tinggi" name="tinggi__" type="text" class="form-control">
        </div>
      </div>
      <div class="form-group row">
        <label for="umur" class="col-4 col-form-label">Umur</label>
        <div class="col-8">
          <input id="umur" name="umur__" type="text" class="form-control">
        </div>
      </div>
      <div class="form-group row">
        <label class="col-4">Jenis Kelamin</label>
        <div class="col-8">
          <div class="form-check mr-auto">
            <input class="form-check-input" type="radio" id="laki" name="jenis__kelamin" value="Laki-Laki" required>
            <label class="form-check-label mr-5" for="laki">
              Laki-Laki
            </label>
            <input class="form-check-input" type="radio" id="perempuan" name="jenis__kelamin" value="Perempuan" required>
            <label class="form-check-label" for="perempuan">
              Perempuan
            </label>
          </div>
        </div>
      </div>
      <div class="form-group row">
        <div class="offset-4 col-8">
          <input type="submit" value="SIMPAN" name="proses">
        </div>
      </div>
    </form>
  </div>
  <hr>
  <?php require_once "ClassBMI.php"; ?>
  

  <div class="container">
    <h2 class="text-center mb-5">Data BMI Pasien</h2>
    <table class="table table-hover table-striped">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Nama Lengkap</th>
          <th scope="col">Gender</th>
          <th scope="col">Umur</th>
          <th scope="col">Berat</th>
          <th scope="col">Tinggi</th>
          <th scope="col">BMI</th>
          <th scope="col">Hasil</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $nomor = 1;
        foreach ($ar_pasien as $pasien) {
          echo '<tr><td>' . $nomor . '</td>';
          echo '<td>' . $pasien['nama'] . '</td>';
          echo '<td>' . $pasien['kelamin'] . '</td>';
          echo '<td>' . $pasien['umur'] . '</td>';
          echo '<td>' . $pasien['berat'] . '</td>';
          echo '<td>' . $pasien['tinggi'] . '</td>';
          $BMI = $pasien["berat"] / (($pasien["tinggi"] / 100) ** 2);
          echo '<td>' . number_format($BMI, 1) . '</td>';
          $status = new bmiPasien();
          echo $status->statusBMI($BMI);
          echo '</tr>';
          $nomor++;
        }
        ?>
      </tbody>
    </table>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
</body>

</html>